
import pygame
import sys

SIZE = 10
WIN = 5
CELL = 60
MARGIN = 40
WIDTH = HEIGHT = SIZE * CELL + MARGIN * 2

BG = (245, 247, 250)
GRID = (180, 180, 180)
X_COLOR = (66, 135, 245)
O_COLOR = (245, 66, 66)

pygame.init()
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Tic Tac Toe 10x10")
font = pygame.font.SysFont("arial", 36)
big_font = pygame.font.SysFont("arial", 28)

board = [[" "]*SIZE for _ in range(SIZE)]
turn = "X"
winner = None

def check_win(r, c, p):
    for dr, dc in [(1,0),(0,1),(1,1),(1,-1)]:
        cnt = 1
        rr, cc = r+dr, c+dc
        while 0<=rr<SIZE and 0<=cc<SIZE and board[rr][cc]==p:
            cnt+=1; rr+=dr; cc+=dc
        rr, cc = r-dr, c-dc
        while 0<=rr<SIZE and 0<=cc<SIZE and board[rr][cc]==p:
            cnt+=1; rr-=dr; cc-=dc
        if cnt>=WIN: return True
    return False

def draw():
    screen.fill(BG)
    for i in range(SIZE+1):
        pygame.draw.line(screen, GRID, (MARGIN+i*CELL, MARGIN),
                         (MARGIN+i*CELL, MARGIN+SIZE*CELL), 2)
        pygame.draw.line(screen, GRID, (MARGIN, MARGIN+i*CELL),
                         (MARGIN+SIZE*CELL, MARGIN+i*CELL), 2)

    for r in range(SIZE):
        for c in range(SIZE):
            if board[r][c]!=" ":
                color = X_COLOR if board[r][c]=="X" else O_COLOR
                txt = font.render(board[r][c], True, color)
                rect = txt.get_rect(center=(MARGIN+c*CELL+CELL//2,
                                            MARGIN+r*CELL+CELL//2))
                screen.blit(txt, rect)

    if winner:
        msg = big_font.render(f"{winner} THẮNG! Nhấn R để chơi lại", True, (0,0,0))
        screen.blit(msg, (20, 10))

    pygame.display.flip()

while True:
    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            pygame.quit(); sys.exit()
        if e.type == pygame.MOUSEBUTTONDOWN and not winner:
            x,y = e.pos
            if MARGIN<=x<MARGIN+SIZE*CELL and MARGIN<=y<MARGIN+SIZE*CELL:
                c = (x-MARGIN)//CELL
                r = (y-MARGIN)//CELL
                if board[r][c]==" ":
                    board[r][c]=turn
                    if check_win(r,c,turn):
                        winner = turn
                    turn = "O" if turn=="X" else "X"
        if e.type == pygame.KEYDOWN and e.key == pygame.K_r:
            board = [[" "]*SIZE for _ in range(SIZE)]
            turn="X"; winner=None

    draw()
