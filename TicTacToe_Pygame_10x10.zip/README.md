
# Tic Tac Toe 10x10 (Pygame)

## Cách chạy
```
pip install pygame
python main.py
```

- Luật: 5 ô liên tiếp để thắng
- Phím R: chơi lại
